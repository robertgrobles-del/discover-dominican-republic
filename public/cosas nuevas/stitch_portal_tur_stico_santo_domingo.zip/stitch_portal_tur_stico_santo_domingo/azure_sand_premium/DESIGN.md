---
name: Azure & Sand Premium
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#40484c'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#71787d'
  outline-variant: '#c0c7cd'
  surface-tint: '#2a657e'
  primary: '#003345'
  on-primary: '#ffffff'
  primary-container: '#004b63'
  on-primary-container: '#83bad6'
  inverse-primary: '#96ceeb'
  secondary: '#645e49'
  on-secondary: '#ffffff'
  secondary-container: '#e8dfc5'
  on-secondary-container: '#68634d'
  tertiary: '#003441'
  on-tertiary: '#ffffff'
  tertiary-container: '#004c5e'
  on-tertiary-container: '#00c3ee'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bfe8ff'
  primary-fixed-dim: '#96ceeb'
  on-primary-fixed: '#001f2b'
  on-primary-fixed-variant: '#044d65'
  secondary-fixed: '#ebe2c8'
  secondary-fixed-dim: '#cec6ad'
  on-secondary-fixed: '#1f1c0b'
  on-secondary-fixed-variant: '#4c4733'
  tertiary-fixed: '#b7eaff'
  tertiary-fixed-dim: '#4cd6ff'
  on-tertiary-fixed: '#001f28'
  on-tertiary-fixed-variant: '#004e60'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  unit-xs: 4px
  unit-sm: 8px
  unit-md: 16px
  unit-lg: 32px
  unit-xl: 64px
---

## Brand & Style

This design system is built for a premium tourism portal, evoking the serenity and exclusivity of high-end Caribbean travel. The brand personality is **Sophisticated, Immersive, and Effortless**. It targets an affluent audience seeking curated experiences, shifting away from "mass tourism" toward "bespoke discovery."

The visual style is a hybrid of **Minimalism** and **Glassmorphism**. It utilizes expansive white space to let high-resolution photography breathe, while employing translucent, frosted-glass overlays for UI elements to maintain a sense of depth and connection to the background scenery. The mood is calm and inviting, yet precisely engineered to convey luxury and reliability.

## Colors

The palette is derived from the natural transitions of the Caribbean coastline.
- **Primary (Deep Blue):** Used for navigation bars, primary headings, and grounding elements. It represents the depth of the ocean and provides strong contrast against light backgrounds.
- **Secondary (Warm Sand):** A soft, sophisticated neutral used for section backgrounds, subtle borders, and call-out containers to add warmth.
- **Tertiary (Vibrant Cyan):** An accent color used sparingly for interactive highlights, icons, and focus states to mirror the shallow, sunlit waters.
- **Neutral:** A range of rich grays and off-whites. Pure black is avoided in favor of a "Midnight Ink" (#1A1A1A) to maintain a softer, premium feel.

The default mode is **Light**, emphasizing brightness and clarity, though components should support translucent "Glass" states when positioned over immersive imagery.

## Typography

The typography strategy balances modern geometry with high readability. 
- **Plus Jakarta Sans** is used for all headlines and display text. Its soft, contemporary curves feel welcoming yet professional.
- **Manrope** handles the body and label text. Its balanced proportions ensure clarity even in data-heavy booking widgets or long-form destination descriptions.

**Hierarchy Rules:**
- Large display text should often appear white or in high-contrast deep blue over photographic backgrounds.
- Use wide letter-spacing and uppercase styling for `label-sm` to denote categories or sub-headers (e.g., "FEATURED DESTINATION").

## Layout & Spacing

The design system utilizes a **Fluid Grid** with a generous 12-column structure for desktop. 
- **Generous Breathing Room:** Vertical rhythm is driven by `unit-xl` (64px) between major sections to prevent visual clutter.
- **Immersive Frames:** Heroes and featured galleries should break the container to go full-width, while textual content remains centered in a `container-max` (1280px) wrapper.
- **Mobile Reflow:** On mobile devices, margins shrink to 20px, and multi-column grids (like destination cards) stack vertically or transition into horizontal carousels to maintain photo aspect ratios.

## Elevation & Depth

Visual hierarchy is established through a combination of **Glassmorphism** and **Ambient Shadows**.

1.  **Level 0 (Base):** Solid white or "Warm Sand" backgrounds.
2.  **Level 1 (Floating Cards):** Semi-transparent white surfaces (`rgba(255, 255, 255, 0.7)`) with a `backdrop-filter: blur(12px)`. These elements use a very soft, diffused shadow (`0px 10px 30px rgba(0, 75, 99, 0.05)`) tinted with the primary blue.
3.  **Level 2 (Interactive/Focus):** Increased blur and a thin, low-opacity white border (1px) to simulate light catching the edge of a glass pane.

Avoid heavy, dark shadows. The goal is "weightless" depth where elements feel like they are floating just above the water or sand.

## Shapes

The shape language is **Softly Rounded**, providing a premium feel that avoids the childishness of full pill-shapes or the coldness of sharp corners.

- **Cards and Containers:** Use `rounded-lg` (1rem / 16px) for a substantial, modern feel.
- **Interactive Elements:** Buttons and input fields use `rounded` (0.5rem / 8px).
- **Small Accents:** Tags and chips use pill-shapes to differentiate them from larger interactive blocks.
- **Imagery:** Large photos should occasionally use "capsule" or asymmetric rounded clipping (as seen in reference images) to create a dynamic, editorial layout.

## Components

### Buttons
- **Primary:** Solid Deep Blue background with White text. Sharp corners or subtle 8px radius. High-end feel with a slight scale-up on hover.
- **Secondary (Glass):** Transparent background with a 1px white border and 12px backdrop-blur. Ideal for placement over photography.
- **Tertiary:** Text-only with a Cyan arrow or underline on hover.

### Destination Cards
Cards must feature high-aspect-ratio images (typically 4:5 or 16:9). Text overlays should use a subtle dark-to-transparent gradient at the bottom to ensure the white typography (Plus Jakarta Sans) remains legible.

### Search & Filters
Horizontal bars with integrated inputs for "Location," "Dates," and "Guests." Use a "Glass" background when positioned in the hero area and a solid "Warm Sand" background when sticky in the results page.

### Chips & Tags
Small, uppercase labels with a semi-transparent Cyan or Sand background. Used for categories like "Luxury," "Beachfront," or "All-Inclusive."

### Input Fields
Minimalist style. 1px solid border in light gray that transitions to Deep Blue on focus. Labels should be small and positioned above the field for maximum clarity.