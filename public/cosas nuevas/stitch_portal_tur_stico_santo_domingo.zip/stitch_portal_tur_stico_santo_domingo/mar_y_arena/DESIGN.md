---
name: Mar y Arena
colors:
  surface: '#f7f9ff'
  surface-dim: '#d5dae2'
  surface-bright: '#f7f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4fc'
  surface-container: '#e9eef6'
  surface-container-high: '#e3e9f0'
  surface-container-highest: '#dde3eb'
  on-surface: '#161c22'
  on-surface-variant: '#404751'
  inverse-surface: '#2b3137'
  inverse-on-surface: '#ecf1f9'
  outline: '#707882'
  outline-variant: '#c0c7d2'
  surface-tint: '#00629e'
  primary: '#005e97'
  on-primary: '#ffffff'
  primary-container: '#0077be'
  on-primary-container: '#f7f9ff'
  inverse-primary: '#9acbff'
  secondary: '#675d49'
  on-secondary: '#ffffff'
  secondary-container: '#f0e1c7'
  on-secondary-container: '#6e634f'
  tertiary: '#9e380d'
  on-tertiary: '#ffffff'
  tertiary-container: '#bf5025'
  on-tertiary-container: '#fff8f6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cfe5ff'
  primary-fixed-dim: '#9acbff'
  on-primary-fixed: '#001d34'
  on-primary-fixed-variant: '#004a79'
  secondary-fixed: '#f0e1c7'
  secondary-fixed-dim: '#d3c5ac'
  on-secondary-fixed: '#221b0b'
  on-secondary-fixed-variant: '#4f4633'
  tertiary-fixed: '#ffdbcf'
  tertiary-fixed-dim: '#ffb59c'
  on-tertiary-fixed: '#380c00'
  on-tertiary-fixed-variant: '#822800'
  background: '#f7f9ff'
  on-background: '#161c22'
  surface-variant: '#dde3eb'
  surface-light: '#F8F9FA'
  surface-sand: '#FCF7ED'
  text-muted: '#64748B'
  success-palm: '#2D6A4F'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.4'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style

The design system embodies a **Tropical Sophistication** style—a fusion of high-end editorial travel guides and modern, digital-first exploration tools. The brand personality is vibrant, welcoming, and professional, designed to evoke the warmth of the Dominican sun and the refreshing clarity of the Caribbean Sea.

The visual direction follows **Modern Minimalism** with a **Tactile** twist. We prioritize high-quality photography and expansive whitespace to allow the destination's beauty to lead the experience. To differentiate from standard government or corporate portals, we use subtle depth through soft shadows and organic, rounded shapes that mimic the fluidity of coastal landscapes. The interface should feel "premium yet reachable," encouraging users to discover the hidden gems of Santo Domingo with ease and confidence.

## Colors

The palette is anchored by **Azul Caribe**, a deep, reliable blue that represents the surrounding sea and professional tourism standards. **Arena Caribe** serves as a warm, inviting secondary tone for backgrounds and subtle containers, preventing the UI from feeling cold or overly clinical.

**Coral** is our high-energy accent, reserved exclusively for primary calls to action (CTAs), markers, and critical interaction points to ensure high visibility against the blue and sand tones. The neutral palette shifts from a clean white for primary surfaces to a dark, legible gray for typography to maintain WCAG AA accessibility. Use "Surface Sand" for large sectional backgrounds to provide a warm, premium feel that differentiates the portal from generic white-label sites.

## Typography

This design system utilizes **Plus Jakarta Sans** for headlines to provide a friendly, optimistic, and contemporary geometric feel. Its soft curves complement the "welcoming" brand pillar. For body text, **Inter** is employed for its exceptional legibility and systematic performance, ensuring that long-form travel guides and practical information are easy to digest across all devices.

The hierarchy is strictly enforced:
- **Display** styles are used for Hero sections with photographic backgrounds.
- **Label** styles use increased letter spacing and uppercase casing to denote categories (e.g., "GASTRONOMÍA", "MONUMENTOS").
- **Body-lg** is the default for blog articles and destination descriptions to enhance the "premium guide" reading experience.

## Layout & Spacing

The layout is built on a **12-column fluid grid** for desktop and a **4-column grid** for mobile. We utilize an 8px base unit to maintain a consistent rhythmic scale across all components.

- **Desktop (1024px+):** 12 columns with 24px gutters. Use generous margins (48px) to emphasize the premium, spacious feel.
- **Tablet (768px - 1023px):** 8 columns with 20px gutters.
- **Mobile (320px - 767px):** 4 columns with 16px gutters and margins.

Spacing should favor "Exploration before Search." This means content sections (like "Nearby Places") should have significant vertical padding (80px–120px on desktop) to create a sense of discovery and prevent the interface from feeling cluttered or "transactional."

## Elevation & Depth

To achieve the "Tropical Sophistication" aesthetic, we avoid heavy, dark shadows. Instead, we use **Ambient Shadows** and **Tonal Layering**:

1.  **Low Elevation:** Used for cards and secondary buttons. A very soft, diffused shadow with a slight Azul Caribe tint (#0077BE at 5% opacity) to make elements feel like they are resting gently on the sandy surface.
2.  **High Elevation:** Reserved for floating action buttons (like "View Map") and navigation headers when scrolling.
3.  **Glassmorphism:** Applied to the primary navigation bar and image overlays. A backdrop-blur of 12px with a 70% white tint creates a modern, airy feel that doesn't obscure the beautiful photography beneath.

## Shapes

The shape language is consistently **Rounded**, reflecting the soft, organic nature of islands and waves. 

- **Cards & Inputs:** Use the base 8px (`0.5rem`) radius.
- **Large Container/Hero Images:** Use `rounded-xl` (24px / 1.5rem) to frame photography elegantly.
- **Buttons & Tags:** Use pill-shaped (full radius) for secondary tags and categories to distinguish them from functional, rectangular buttons.

This roundedness should be applied to all interactive elements to maintain the "welcoming" and "friendly" emotional response.

## Components

### Buttons
- **Primary:** Coral background, white text, 8px radius. High-contrast for "Book Now" or "Explore."
- **Secondary:** Azul Caribe outline, azul text, 8px radius.
- **Tertiary/Ghost:** No background, Azul Caribe text with a small leading icon.

### Cards (The "Lugar" Card)
The core component of the system. It features a top-aligned image with a 16:9 aspect ratio. The content area uses the "Surface Sand" color to separate it from the white background. Information includes a "Coral" category label, title in Plus Jakarta Sans, and a bottom row for "Distance" and "Rating" using neutral muted text.

### Inputs & Search
Search bars should be oversized with a 16px vertical padding and a leading "Lucide Search" icon. Backgrounds are white with a subtle 1px gray-200 border, shifting to a 2px Azul Caribe border on focus.

### Chips & Tags
Used for filtering (e.g., "Museos", "Zonas Verdes"). These should be pill-shaped. Active states use Azul Caribe with white text; inactive states use a light gray or Arena Caribe background.

### Navigation
The Navbar is fixed with a glassmorphism effect. Icons (Lucide) are used alongside labels on mobile for the PWA experience, ensuring a "thumb-friendly" bottom navigation bar for mobile users.

### Map Pins
Custom markers using the Coral color for the selected location and Azul Caribe for all other points of interest. Pins should feature a small category icon (e.g., a fork/knife for Gastronomy) inside the pin head.